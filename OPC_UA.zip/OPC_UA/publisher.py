from opcua import Server
import time
import random
import paho.mqtt.client as mqtt

# OPC UA Server setup
server = Server()
server.set_endpoint("opc.tcp://0.0.0.0:4840/freeopcua/server/")
uri = "http://example.org"
idx = server.register_namespace(uri)
obj = server.nodes.objects.add_object(idx, "SensorData")
variables = {"temperature": obj.add_variable(idx, "Temperature", 0.0),
             "pressure": obj.add_variable(idx, "Pressure", 0.0),
             "humidity": obj.add_variable(idx, "Humidity", 0.0)}
server.start()

# MQTT Broker setup
mqtt_client = mqtt.Client()
mqtt_client.connect("localhost", 1883, 60)

try:
    while True:
        # Generate random data for each variable
        for var_name, variable in variables.items():
            data_value = random.uniform(20.0, 30.0)  # Replace with actual data source
            variable.set_value(data_value)

            # Publish data to MQTT broker
            mqtt_payload = f"{var_name}: {data_value}"
            mqtt_client.publish(f"opcua/{var_name}", mqtt_payload)

        time.sleep(1)

finally:
    server.stop()
    server.iserver.stop()
    mqtt_client.disconnect()
