from opcua import Client
import time
import paho.mqtt.client as mqtt
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS

# OPC UA Client setup
client = Client("opc.tcp://192.168.0.126:4840/freeopcua/server/")
client.connect()
subscription = client.create_subscription(500, lambda: None)

# InfluxDB setup
influx_url = "http://192.168.0.100:8086"
influx_token = "th31sUEcYXP-ev2DgfjTZDkgwCVUMOum1O3i5KTxHa2PMwkEf2M5p9su6VfNhk0MqjVG-iLqUSIwLdeHQhvG-A=="
influx_org = "harting"
influx_bucket = "aas_data_rpi"

influx_client = InfluxDBClient(url=influx_url, token=influx_token, org=influx_org)
write_api = influx_client.write_api(write_options=SYNCHRONOUS)

def data_changed(var_name, var, val, data):
    print(f"Received {var_name} from OPC UA: {val}")

    # Store data in InfluxDBP
    timestamp_ns = int(time.time() * 1e9)  # Convert seconds to nanoseconds
    point = Point(var_name).field("value", val).time(timestamp_ns, WritePrecision.NS)
    write_api.write(bucket=influx_bucket, record=point)

# Subscribe to the variables in OPC UA
for var_name, variable in client.get_node("ns=1;i=2").get_variables():
    handle = subscription.subscribe_data_change(variable, lambda val, data, name=var_name: data_changed(name, variable, val, data))

# MQTT Client setup
def on_message(client, userdata, msg):
    print(f"Received {msg.topic} from MQTT: {msg.payload}")

    # Store data in InfluxDB
    timestamp_ns = int(time.time() * 1e9)  # Convert seconds to nanoseconds
    var_name = msg.topic.split("/")[-1]
    point = Point(var_name).field("value", float(msg.payload.split(b":")[1])).time(timestamp_ns, WritePrecision.NS)
    write_api.write(bucket=influx_bucket, record=point)

mqtt_client = mqtt.Client()
mqtt_client.on_message = on_message
mqtt_client.connect("192.168.0.100", 1883, 60)

# Subscribe to the topics in MQTT
for var_name in ["temperature", "pressure", "humidity"]:
    mqtt_client.subscribe(f"opcua/{var_name}")

mqtt_client.loop_start()

try:
    while True:
        time.sleep(1)

finally:
    # Close connections
    subscription.unsubscribe(handle)
    client.disconnect()
    # mqtt_client.disconnect()
    influx_client.close()
