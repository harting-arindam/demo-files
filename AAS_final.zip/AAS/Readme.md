TODO:

1. Develop A timeseries submodel that updates from the Time-Series Database
2. Refactor the package
3. create a flow (CLI)"# aas" 
