import os
from basyx.aas import model
from basyx.aas import adapter
from basyx.aas.adapter import aasx

from create_property import create_property
from asset import create_asset
from timeseries import timeseries_submodel
from Submodel_Element_Collection import create_Submodel_Element_Collection
from identifier import create_semantic_id_irdi
from pathlib import Path
import basyx.aas.adapter.json
import basyx.aas.adapter.xml


file_store = aasx.DictSupplementaryFileContainer()
obj_store: model.DictObjectStore[model.Identifiable] = model.DictObjectStore()


    
# /aasx/files/PDF_DS_09200030801_DE.pdf
asset = create_asset('HARTINGAAS','https://example.com/asset/1')

submodel_timeseries = timeseries_submodel()



aas = model.AssetAdministrationShell(
    identification=model.Identifier('https://acplt.org/Simple_AAS/timeseies', model.IdentifierType.IRI),
    id_short="TimeseriesWithValue",
    asset=model.AASReference.from_referable(asset),
    submodel={
        model.AASReference.from_referable(submodel_timeseries),
              }
)

obj_store.add(asset)
obj_store.add(submodel_timeseries)


obj_store.add(aas)

with aasx.AASXWriter(r"E:\@rindam_HAT-BLR\AASX files\demo-files\TimeseriesAAS.aasx") as writer:
    writer.write_aas(aas_id=model.Identifier('https://acplt.org/Simple_AAS/timeseies',model.IdentifierType.IRI),
                     object_store=obj_store,
                     file_store=file_store,
                     submodel_split_parts=False)
    
with open('timeseries.xml', 'wb') as xml_file:
    basyx.aas.adapter.xml.write_aas_xml_file(xml_file, obj_store)

with open('timeseries.json', 'w', encoding='utf-8') as json_file:
    basyx.aas.adapter.json.write_aas_json_file(json_file, obj_store)
    
  
    
