from basyx.aas import model
from typing import Optional

# def create_operations(name:str,semantic_id:model.Reference,value):



def create_blob(name:str,semantic_id:model.Reference,value:Optional[model.BlobType]=None):
    blob=model.Blob(
        id_short=name,
        mime_type='application/pdf',
        value=value,
        category='PARAMETER',
        description={'en-us': 'Example Blob object',
                     'de': 'Beispiel Blob Element'},
        parent=None,
        semantic_id=semantic_id,
        qualifier=None,
        kind=model.ModelingKind.INSTANCE)
    return blob
