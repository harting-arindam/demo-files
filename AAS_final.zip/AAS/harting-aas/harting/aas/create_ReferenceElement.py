from basyx.aas import model   
from identifier import create_semantic_id_iri
from typing import Optional
from pathlib import Path

import pandas as pd
df = pd.read_csv(Path(__file__).parent / 'Prop_Lang_CSV' / 'Reference_element.csv')



def create_reference_element(name:str,value:Optional[model.Reference]=None,semantic_id:model.Reference=None,qualifier:Optional[str]=None):
    return model.ReferenceElement(
        id_short=name,
        value=value,
        semantic_id=semantic_id,
        qualifier=qualifier,
        kind=model.ModelingKind.INSTANCE)
def create_reference_element_multi(name_value:dict,semantic_id_key_type:Optional[model.KeyElements]=model.KeyElements.GLOBAL_REFERENCE,qualifier:Optional[str]=None):
    list_=[]
    for key,value in name_value.items():
        ref = model.ReferenceElement(
            id_short=key,
            value=value,
            semantic_id=create_semantic_id_iri(value = df.query(f"Reference_Element=='{key}'")["IRI_IRDI"].to_string(index=False),local=True,key_type=semantic_id_key_type),
            qualifier=qualifier,
            kind=model.ModelingKind.INSTANCE)
        list_.append(ref)
    return list_


