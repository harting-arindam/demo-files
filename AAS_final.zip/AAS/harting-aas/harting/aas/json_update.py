import json
from datetime import datetime
import random
from subscriber import OPCUAMQTTClient
import time

opcua_mqtt_client = OPCUAMQTTClient()


# Function to modify the "value" field in the JSON structure for a given parameter
def modify_parameter_value(json_data, parameter_id, new_value):
    # Locate the "value" field of the specified parameter
    for parameter in json_data['value']:
        if parameter['idShort'] == parameter_id:
            # Modify the "value" field
            parameter['value'] = new_value

# Function to update the "idShort" field with the current date and time
def update_id_short(json_data):
    current_date_time = datetime.now().isoformat(timespec='seconds') + 'Z'
    json_data['idShort'] = f"Record_{current_date_time}"

# Example usage
json_file_path = 'payload.json'

# Read the existing JSON file
with open(json_file_path, 'r') as file:
    data = json.load(file)

# Update the "idShort" field with the current date and time
update_id_short(data)

# Modify the "value" field of the "Time" parameter with the current date and time
current_date_time_value = datetime.now().isoformat(timespec='seconds') + 'Z'
modify_parameter_value(data, 'Time', current_date_time_value)

# Modify the "value" field of the "Temperature" parameter with a new value


try:
    while True:
        time.sleep(5)
        # Access the value attribute directly
        value = opcua_mqtt_client.value_from_message
        # print(f"Value from on_message: {value}")
        new_temperature_value = value
        # new_temperature_value = 'your_new_temperature_value'
        modify_parameter_value(data, 'Temparature', new_temperature_value)

        # Write the modified data back to the JSON file
        with open(json_file_path, 'w') as file:
            json.dump(data, file, indent=2)

except KeyboardInterrupt:
    opcua_mqtt_client.client.disconnect()
    opcua_mqtt_client.influx_client.close()






