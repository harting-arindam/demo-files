# imports 

from basyx.aas import model
from typing import Optional

def create_operations(name:str,semantic_id:model.Reference,input_submodelElement:Optional[list[model.SubmodelElement]]=None,output_SubmodelElement:Optional[model.SubmodelElement]=None,in_output_SubmodelElement:Optional[model.SubmodelElement]=None):
    ise_list=[]
    if input_submodelElement==None:
        ise_list = None
    else:
        for ise in input_submodelElement:
            submodel_element_operation_variable_input = model.OperationVariable(
                value=ise)
            ise_list.append(submodel_element_operation_variable_input)

    ose_list=[]
    if output_SubmodelElement==None:
        ose_list = None
    else:
        for ose in output_SubmodelElement:
            submodel_element_operation_variable_output = model.OperationVariable(
                value=ose)
            ose_list.append(submodel_element_operation_variable_output)

    inose_list=[]
    if in_output_SubmodelElement==None:
        inose_list=None   
    else:
        for inou in in_output_SubmodelElement:
            submodel_element_operation_variable_in_output = model.OperationVariable(
                value=in_output_SubmodelElement)
            inose_list.append(submodel_element_operation_variable_in_output)


    submodel_element_operation = model.Operation(
        id_short=name,
        input_variable=ise_list,
        output_variable=ose_list,
        in_output_variable=inose_list,
        category='PARAMETER',
        description={'en-us': 'Example Operation object',
                     'de': 'Beispiel Operation Element'},
        parent=None,
        semantic_id=semantic_id,
        kind=model.ModelingKind.INSTANCE)
    
    return submodel_element_operation