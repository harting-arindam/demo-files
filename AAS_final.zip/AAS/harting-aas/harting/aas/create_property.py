from basyx.aas import model
from typing import Optional
from identifier import create_id_short,create_semantic_id_irdi,create_semantic_id_iri
from pathlib import Path


import pandas as pd
# df --> csv for property
# df1 --> csv for multi-lang-property
Path(__file__).parent / 'data' / 'TestFile.pdf'

df = pd.read_csv(Path(__file__).parent / 'Prop_Lang_CSV' / 'Property.csv')
df1 = pd.read_csv(Path(__file__).parent / 'Prop_Lang_CSV' / 'Multilanguage_Property.csv')


# prop_dictionary = {'DocumentDomainId': document_domain_id, "ValueId": Path(value_id).stem, "IsPrimary": str(is_primary)}
def create_property(name_value:dict,semantic_id_type:str='IRDI',semantic_id_key_type:Optional[model.KeyElements]=model.KeyElements.GLOBAL_REFERENCE,value_type:Optional[model.DataTypeDef]=model.datatypes.String,descrption:Optional[str]=None,qualifier:Optional[str]=None):
    list_=[]
    for key,value in name_value.items():
        if semantic_id_type == 'IRI':
            prop = model.Property(
                    id_short= key,
                    value_type=value_type,
                    value=value,
                    category="PARAMETER",
                    parent=None,
                    semantic_id=create_semantic_id_iri(value = df.query(f"Property=='{key}'")["IRI_IRDI"].to_string(index=False),local=True,key_type=semantic_id_key_type),
                    description=descrption,
                    qualifier=qualifier
                    )
            list_.append(prop)
        elif semantic_id_type == 'IRDI':
            prop = model.Property(
                    id_short= key,
                    value_type=value_type,
                    value=value,
                    category="PARAMETER",
                    parent=None,
                    semantic_id=create_semantic_id_irdi(value = df.query(f"Property=='{key}'")["IRI_IRDI"].to_string(index=False),local=True,key_type=semantic_id_key_type),
                    description=descrption,
                    qualifier=qualifier
                    )
            list_.append(prop)
        else:
            return print("Enter the semantic_id type correctly")
    return list_
        


# def create_property(name:str,semantic_id:Optional[model.Reference]=None,value_type:Optional[model.DataTypeDef]=None,value:Optional[model.ValueDataType]=None,descrption:Optional[str]=None,qualifier:Optional[str]=None):
    
#     return model.Property(
#             id_short= create_id_short(name),
#             value_type=value_type,
#             value=value,
#             category="PARAMETER",
#             parent=None,
#             semantic_id=semantic_id,
#             description=descrption,
#             qualifier=qualifier
#             )

# def create_multilanguageproperty(name:str,semantic_id:model.Reference,value_id:Optional[model.Reference]=None,value:Optional[model.LangStringSet]=None,descrption:Optional[str]=None,qualifier:Optional[str]=None):
    
#     return model.MultiLanguageProperty(
#             id_short= create_id_short(name),
#             value_id=value_id,
#             value=value,
#             category="LANG-PARAMETER",
#             parent=None,
#             semantic_id=semantic_id,
#             description=descrption,
#             qualifier=qualifier
#             )


def create_multilanguageproperty(name_value:dict,semantic_id_type:str='iri',semantic_id_key_type:Optional[model.KeyElements]=model.KeyElements.GLOBAL_REFERENCE,value_id:Optional[model.Reference]=None,descrption:Optional[str]=None,qualifier:Optional[str]=None):
    list_=[]
    for key,value in name_value.items():
        if semantic_id_type == 'IRI':
            lang = model.MultiLanguageProperty(
                    id_short= key,
                    value_id=value_id,
                    value=value,
                    category="LANG-PARAMETER",
                    parent=None,
                    semantic_id=create_semantic_id_iri(value = df1.query(f"Multilang_Property=='{key}'")["IRI_IRDI"].to_string(index=False),local=True,key_type=semantic_id_key_type),
                    description=descrption,
                    qualifier=qualifier
                    )
            list_.append(lang)
        elif semantic_id_type == 'IRDI':
            lang = model.MultiLanguageProperty(
                    id_short= key,
                    value_id=value_id,
                    value=value,
                    category="LANG-PARAMETER",
                    parent=None,
                    semantic_id=create_semantic_id_irdi(value = df1.query(f"Multilang_Property=='{key}'")["IRI_IRDI"].to_string(index=False),local=True,key_type=semantic_id_key_type),
                    description=descrption,
                    qualifier=qualifier
                    )
            list_.append(lang)
            
        else:
            return print("Enter the semantic_id type correctly")
    return list_
# # model.Reference()

