# TODO: Pending for Completion
# imports

from basyx.aas import model
from pathlib import Path
from typing import Optional

from create_ReferenceElement import create_reference_element,create_reference_element_multi

from identifier import create_id,create_semantic_id_irdi,create_semantic_id_iri
from Submodel_Element_Collection import create_Submodel_Element_Collection
from create_property import create_property,create_multilanguageproperty




# ---------------------------------------------Properties---------------------------------------------


# ------------------------------------------------SME--------------------------------------------------
def create_plantmetadata_sme():

    return create_Submodel_Element_Collection(name='Interfaces',
                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/ControlComponent/Type/Interfaces/1/0',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                            value=
                                            create_reference_element_multi(
                                                        name_value={'EnterpriseReference':create_semantic_id_iri(value ='http://example.com/id/9992020020616052921',local=False,key_type=model.KeyElements.ENTITY),
                                                                    'SiteReference':create_semantic_id_iri(value ='http://example.com/id/9992020020616052922',local=False,key_type=model.KeyElements.ENTITY),
                                                                    'IndustrialComplexReference':create_semantic_id_iri(value ='http://example.com/id/9992020020616052923',local=False,key_type=model.KeyElements.ENTITY),
                                                                    'ProcessPlantReference':create_semantic_id_iri(value ='http://example.com/id/9992020020616052924',local=False,key_type=model.KeyElements.ENTITY),
                                                                    'PlantSectionReference':create_semantic_id_iri(value ='http://example.com/id/9992020020616052925',local=False,key_type=model.KeyElements.ENTITY),
                                                                    },
                                              
                                                        semantic_id_key_type=model.KeyElements.GLOBAL_REFERENCE
                                                        )+
                                            create_property(
                                                        name_value={'EnterpriseIdentificationCode': '','EnterpriseName':'','IndustrialComplexIdentificationCode':'','IndustrialComplexName':'',
                                                                    'PlantSectionIdentificationCode':'','PlantSectionName':'','ProcessPlantIdentificationCode':'','ProcessPlantName':'',
                                                                    'ProjectName':'','ProjectNumber':'','SiteIdentificationCode':'','SiteName':'',
                                                                    'SubProjectName':'','SubProjectNumber':'','ManufacturerName':'','DateOfManufacture':'','EndProductCASName':'','EndProductName':''},
                                                        semantic_id_type='IRI',
                                                        semantic_id_key_type=model.KeyElements.GLOBAL_REFERENCE
                                                        )                   
                        
                                            )





# # ------------------------------------Submodel--------------------------------------------------


# def nameplate_submodel(manufacturer_name:list[str],file_upload:list[str]) -> model.Submodel:
def dexpi_submodel() -> model.Submodel:
 
    submodel_creation=model.Submodel(
        id_short='DEXPI',
        identification=create_id('https://epc.org/sm_id/9f236679-e52d-4a52-aa85-dea871a89f9b','IRI'), # check the identifier
        category='Submodel',
        submodel_element=
                        [create_plantmetadata_sme()]
                        
                )

    return submodel_creation

