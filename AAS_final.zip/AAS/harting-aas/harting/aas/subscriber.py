from opcua import Client
import time
import paho.mqtt.client as mqtt
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS


class OPCUAMQTTClient:
    def __init__(self):
        # OPC UA Client setup
        self.client = Client("opc.tcp://192.168.10.134:4840/freeopcua/server/")
        self.client.connect()
        self.subscription = self.client.create_subscription(100, lambda: None)

        # InfluxDB setup
        self.influx_url = "http://localhost:8086"
        self.influx_token = "7jQK7A0Vpgr_iUVu5f0BLX0DRxT3oO3J-b0s2HTNWI6Fw4q5wrnd6DGQDay6dDwyBUXv4XaIxgmxZwKAFpQA1w=="
        self.influx_org = "harting"
        self.influx_bucket = "aas_data_rpi"

        self.influx_client = InfluxDBClient(url=self.influx_url, token=self.influx_token, org=self.influx_org)
        self.write_api = self.influx_client.write_api(write_options=SYNCHRONOUS)

        # MQTT Client setup
        self.mqtt_client = mqtt.Client()
        self.mqtt_client.on_message = self.on_message
        self.mqtt_client.connect("192.168.10.248", 1883, 60)

        # Subscribe to the topics in MQTT
        for var_name in ["temperature"]:
            self.mqtt_client.subscribe(f"opcua/{var_name}")
        
        self.value_from_message = None


        self.mqtt_client.loop_start()

    def on_message(self, client, userdata, msg):
        print(f"Received {msg.topic} from MQTT: {msg.payload}")

        # Store data in InfluxDB
        timestamp_ns = int(time.time() * 1e9)  # Convert seconds to nanoseconds
        var_name = msg.topic.split("/")[-1]
        point = Point(var_name).field("value", float(msg.payload.split(b":")[1])).time(timestamp_ns, WritePrecision.NS)
        self.write_api.write(bucket=self.influx_bucket, record=point)
        self.value_from_message = float(msg.payload.split(b":")[1])
        # Return the value
        return float(msg.payload.split(b":")[1])

    def run(self):
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            # Close connections
            self.client.disconnect()
            self.mqtt_client.disconnect()
            self.influx_client.close()


if __name__ == "__main__":
    opcua_mqtt_client = OPCUAMQTTClient()
    opcua_mqtt_client.run()
