import pyecma376_2


def write_aasx_to_xml(aasx_file:str,xml_filename:str):

    with pyecma376_2.ZipPackageReader(aasx_file) as reader:
        for part_name, content_type in reader.list_parts():
            if part_name.endswith('.aas.xml'):
                xml = part_name
                a=reader.open_item(xml)
                
        
        with open(xml_filename, 'wb') as xml_file:
            xml_file.write(a.read())


    pass




        


        





