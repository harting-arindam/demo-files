# imports

from basyx.aas import model
from pathlib import Path
from typing import Optional

from create_ReferenceElement import create_reference_element

from identifier import create_id,create_semantic_id_irdi,create_semantic_id_iri
from Submodel_Element_Collection import create_Submodel_Element_Collection
from create_property import create_property,create_multilanguageproperty
from create_operations import create_operations
from create_blob import create_blob
from create_range import create_range




# ---------------------------------------------Properties---------------------------------------------


# ------------------------------------------------SME--------------------------------------------------
def create_metadata_sme():
    return create_Submodel_Element_Collection(name='Metadata',
                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/Metadata/1/1',local=False,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                            value=
                                                create_multilanguageproperty(
                                                    name_value={'Name':'','Description':''},
                                                    semantic_id_type='IRI',
                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                               [create_Submodel_Element_Collection(name='Record',
                                                                        semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/Record/1/1',local=False,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                                        value=create_property(
                                                                                name_value={'Time':'','sampleAccelerationX':'','sampleAccelerationY':'','sampleAccelerationZ':''},
                                                                                semantic_id_type='IRDI',
                                                                                semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
                                                                                )]
                                        )
def create_record_sme():
    return 
def create_Segments_sme():
    return create_Submodel_Element_Collection(name='Segments',
                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/Segments/1/1',local=False,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                            value=
                                                    [
                                                    create_Submodel_Element_Collection(
                                                    name='ExternalSegment',
                                                    semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/Segments/ExternalSegment/1/1',local=False,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                    value=
                                                            create_multilanguageproperty(
                                                                name_value={'Name':'','Description':''},
                                                                semantic_id_type='IRI',
                                                                semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+

                                                            create_property(
                                                                name_value={'RecordCount':'','StartTime':'','EndTime':'','Duration':'',
                                                                            'SamplingInterval':'','SamplingRate':'','State':'','LastUpdate':''},
                                                                semantic_id_type='IRI',
                                                                semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                            [
                                                            model.File(
                                                                id_short="ExplanatoryStatement",
                                                                semantic_id=create_semantic_id_iri(value='https://example.com/ids/cd/3291_7022_2032_0718',local=False),
                                                                mime_type="application/pdf",
                                                                # value=filepath,
                                                                ),
                                                            create_blob(name='Blob',
                                                                        semantic_id=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/Blob/1/1',local=False,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                                        )
                                                            
                                                            ]
                                                            ),
                                                    
                                                        

                                                    
                                                    create_Submodel_Element_Collection(
                                                    name='LinkedSegment',
                                                    semanticID=create_semantic_id_iri(value=' https://admin-shell.io/idta/TimeSeries/Segments/LinkedSegment/1/1',local=False,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                    value=
                                                            create_multilanguageproperty(
                                                                name_value={'Name':0,'Description':''},
                                                                semantic_id_type='IRI',
                                                                semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+

                                                            create_property(
                                                                name_value={'RecordCount':'','StartTime':'','EndTime':'','Duration':'',
                                                                            'SamplingInterval':'','SamplingRate':'','State':'','LastUpdate':'',
                                                                            'Endpoint':'http://192.168.0.100:8086','Query':'from(bucket: "{aas_data_rpi}") |> range(start: -1h)'},
                                                                semantic_id_type='IRI',
                                                                semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
                                                    ),
                                                    create_Submodel_Element_Collection(
                                                    name='InternalSegment',
                                                    semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/Segments/InternalSegment/1/1',local=False,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                    value=
                                                            create_multilanguageproperty(
                                                                name_value={'Name':'','Description':''},
                                                                semantic_id_type='IRI',
                                                                semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+

                                                            create_property(
                                                                name_value={'RecordCount':'','StartTime':'','EndTime':'','Duration':'',
                                                                            'SamplingInterval':'','SamplingRate':'','State':'','LastUpdate':'',
                                                                            },

                                                                semantic_id_type='IRI',
                                                                semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                            [
                                                            create_Submodel_Element_Collection(name='Records',
                                                                semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/Records/1/1',local=False,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                                value=[create_Submodel_Element_Collection(name='Record',
                                                                        semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/Record/1/1',local=False,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                                        value=create_property(
                                                                                name_value={'Time':'','Temparature':''},
                                                                                semantic_id_type='IRDI',
                                                                                semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
                                                                                )]+
                                                                    [create_Submodel_Element_Collection(name='Record1',
                                                                        semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/Record/1/2',local=False,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                                        value=create_property(
                                                                                name_value={'Time':'','Temparature':''},
                                                                                semantic_id_type='IRDI',
                                                                                semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
                                                                                )]
                                                                            )
                                                            ]
                                                    )
                                                    ]
                
                                        )

prop= create_property(
        name_value={'SamplingIntervall':'','AggregationMethod':''},
        semantic_id_type='IRI',
        semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
range_timespan = create_range(
        name='Timespan',
        semantic_id=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/Timespan/1/1',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
        
)
smec_segements = create_Submodel_Element_Collection(
        name='Segments',
        semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/AggregationMethod/1/1',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),       
)
smec_record = create_Submodel_Element_Collection(
        name='Records',
        semanticID=None
)

def create_deriveSegment_opr():
    return create_operations(
        name='DeriveSegment',
        semantic_id=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/DeriveSegment/1/1',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
        input_submodelElement=[range_timespan]+prop,
        output_SubmodelElement=[smec_segements],
    )
def create_readsegments_opr():
    return create_operations(
        name='ReadSegments',
        semantic_id=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/ReadSegments/1/1',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
        input_submodelElement=[range_timespan],
        output_SubmodelElement=[smec_segements]
    )
def create_readrecords_opr():
    return create_operations(
        name='ReadRecords',
        semantic_id=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/Timespan/1/1',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
        input_submodelElement=prop,
        output_SubmodelElement=[smec_record]
    )


# test(prop1,smec)


# # ------------------------------------Submodel--------------------------------------------------


# def nameplate_submodel(manufacturer_name:list[str],file_upload:list[str]) -> model.Submodel:
def timeseries_submodel() -> model.Submodel:
 
    submodel_creation=model.Submodel(
        id_short='TimeSeries',
        identification=create_id('https://admin-shell.io/idta/TimeSeries/1/1','IRI'),
        category='Submodel',
        semantic_id=create_semantic_id_iri(value='https://admin-shell.io/idta/TimeSeries/1/1',local=False,key_type=model.KeyElements.GLOBAL_REFERENCE),
        submodel_element=
                        [create_metadata_sme(),
                         create_Segments_sme(),
                         create_deriveSegment_opr(),
                         create_readsegments_opr(),
                         create_readrecords_opr()

                         ]
                        
                )

    return submodel_creation

