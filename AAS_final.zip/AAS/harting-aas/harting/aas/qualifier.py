from basyx.aas import model
def qualifier_cardinality(value:str,local:bool = False)->model.Qualifier:
    '''
    value: value of qualifier cardinality can be ZeroToMany, OneToMany, ZeroToOne, One
    '''
    return model.Qualifier(
    type_='Cardinality',
    value_type=model.datatypes.String,
    value=value,
    value_id=model.Reference((model.Key(type_=model.KeyElements.GLOBAL_REFERENCE,
                                        local=local,
                                        value='http://acplt.org/ValueId/ExampleValueId',
                                        id_type=model.KeyType.IRI),)))   

def qualifier_ExampleValue(value:str,local:bool = False)->model.Qualifier:
    '''
    ExampleValue: 
    '''
    return model.Qualifier(
    type_='ExampleValue',
    value_type=model.datatypes.String,
    value=value,
    value_id=model.Reference((model.Key(type_=model.KeyElements.GLOBAL_REFERENCE,
                                        local=local,
                                        value='http://acplt.org/ValueId/ExampleValueId',
                                        id_type=model.KeyType.IRI),)))   
def qualifier_KeyValue(key:str,value:str,local:bool = False)->model.Qualifier:
    '''
    Key:
    value:
    '''
    return model.Qualifier(
    type_=key,
    value_type=model.datatypes.String,
    value=value,
    value_id=model.Reference((model.Key(type_=model.KeyElements.GLOBAL_REFERENCE,
                                        local=local,
                                        value='http://acplt.org/ValueId/ExampleValueId',
                                        id_type=model.KeyType.IRI),)))   


