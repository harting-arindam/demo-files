from basyx.aas import model
from typing import Optional,Iterable
from create_property import create_property,create_multilanguageproperty
from identifier import create_id,create_semantic_id_iri,create_semantic_id_irdi
from entity import create_entity
from qualifier import qualifier_cardinality,qualifier_ExampleValue,qualifier_KeyValue
from create_ReferenceElement import create_reference_element
from pathlib import Path
from basyx.aas.adapter import aasx

# -------------------------------SME for HandoverDocumentation--------------------------------------------
def create_Submodel_Element_Collection(name:str,
                                       semanticID:model.Reference,
                                       value:Iterable[model.Property] = (),
                                       qualifier:Optional[model.Qualifier]=None
                                      ):
    return model.SubmodelElementCollectionOrdered(id_short=name,
                                                  semantic_id=semanticID,
                                                  value=value,
                                                  qualifier=qualifier)  

def create_documentid_sme(document_domain_id:str,value_id:str,is_primary:bool):
    Submodel_Element = create_Submodel_Element_Collection(
                                name='DocumentID',
                                semanticID=create_semantic_id_irdi(value='0173-1#02-ABI501#001/0173-1#01-AHF580#001',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                # qualifier={qualifier_cardinality('OneToMany')},
                                value=create_property(name_value={'DocumentDomainId':document_domain_id,'ValueId':Path(value_id).stem,'IsPrimary':str(is_primary)},
                                                      semantic_id_type='IRDI',
                                                      semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                ) 
    return Submodel_Element                         

def create_documentclassification_sme(class_name:Optional[model.LangStringSet]):
    Submodel_Element = create_Submodel_Element_Collection(
                        name='DocumentClassification',
                        semanticID=create_semantic_id_irdi(value='0173-1#02-ABI502#001/0173-1#01-AHF581#001',local=False),
                        # qualifier={qualifier_cardinality('OneToMany')},
                        value=create_property(name_value={'ClassId': '123-demo-class-id', "ClassificationSystem": '123-demo-classsystem'},semantic_id_type='IRDI',semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                        create_multilanguageproperty(name_value={'ClassName':class_name},semantic_id_type='IRDI',semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                        )
    return Submodel_Element
                                             


def create_documentversion_sme(title:str,sub_title:Optional[str]='',summary:Optional[str]='',organization_name:str=None,document_language:str='en',filename:str=None,filepath:str=None):
    Submodel_Element = create_Submodel_Element_Collection(
                        name='DocumentVersion',
                        semanticID=create_semantic_id_irdi(value='0173-1#02-ABI503#001/0173-1#01-AHF582#001',local=False),
                        # qualifier={qualifier_cardinality('OneToMany')},
                        value=
                        create_property(name_value={'Language':document_language,'DocumentVersionId':'demo-v1','StatusSetDate':'demo-24-Nov-2023','StatusValue':'demo-active','Organizationname':organization_name,'OrganizationOfficialname':organization_name},
                                        semantic_id_type='IRDI',
                                        semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                        create_multilanguageproperty(name_value={'Title': {document_language:title},'SubTitle':{document_language:sub_title},'Summary':{document_language:summary},'KeyWords':{document_language:summary}},
                                                     semantic_id_type='IRDI',
                                                     semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                        [create_reference_element(
                                    name='RefersTo',
                                    semantic_id=create_semantic_id_irdi(value='0173-1#02-ABI006#001',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                    ),
                        create_reference_element(
                                    name='BasedOn',
                                    semantic_id=create_semantic_id_irdi(value='0173-1#02-ABI007#0011',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                    ),
                        create_reference_element(
                                    name='TranslationOf',
                                    semantic_id=create_semantic_id_irdi(value='0173-1#02-ABI008#001',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                    ),
                        model.File(id_short="documentationFile",
                                    mime_type="application/pdf",
                                    value=filepath)]

                        )
    return Submodel_Element



