# create a AAS-asset by defining the asset and asset name

from basyx.aas import model

def create_asset(AssetName:str,Identifier:str) -> model.Asset:
    """Create a Asset for Asset Administrative Shell.

    Args:
        identification (str): The IRI of the Asset.

    Returns:
        model.Asset.
    """
    asset = model.Asset(
        id_short= AssetName,
        kind=model.AssetKind.INSTANCE,
        identification=model.Identifier(id_=Identifier,
                                        id_type=model.IdentifierType.IRI))
    return asset