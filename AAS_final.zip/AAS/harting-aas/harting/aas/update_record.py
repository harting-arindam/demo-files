import requests
import base64
import json

def UpdateRecords(aasIdentifier: str, submodelIdentifier: str):
    repository_url = "http://localhost:5001/"
    
    aasIdentifier_base64 = base64.b64encode(bytes(aasIdentifier, 'utf-8'))
    submodelIdentifier_base64 = base64.b64encode(bytes(submodelIdentifier, 'utf-8'))

    aasIdentifier_base64=aasIdentifier_base64.decode("utf-8")
    submodelIdentifier_base64=submodelIdentifier_base64.decode("utf-8")
    
    aasx_post_url = f"{str(repository_url)}shells/{str(aasIdentifier_base64)}/submodels/{submodelIdentifier_base64}/submodel-elements/Segments.InternalSegment.Records?first=true"
    print(aasx_post_url)

    
    with open("payload.json", 'r') as file:
      payload = json.load(file)

    response = requests.post(aasx_post_url, json=payload)

    return print(response.text)

# Example usage
UpdateRecords("https://acplt.org/Simple_AAS/timeseies", "https://admin-shell.io/idta/TimeSeries/1/1")
