from opcua import Client
import time
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS
import paho.mqtt.client as mqtt



class OPCUAMQTTClient:
    def __init__(self):
        # OPC UA Client setup
        self.client = Client("opc.tcp://192.168.10.134:4840/freeopcua/server/")
        self.client.connect()

        # InfluxDB setup
        self.influx_url = "http://localhost:8086"
        self.influx_token = "your_influx_token"
        self.influx_org = "your_influx_org"
        self.influx_bucket = "your_influx_bucket"

        self.influx_client = InfluxDBClient(url=self.influx_url, token=self.influx_token, org=self.influx_org)
        self.write_api = self.influx_client.write_api(write_options=SYNCHRONOUS)

        # Initialize the value attribute
        self.value_from_message = None

    def on_message(self, client, userdata, msg):
        print(f"Received {msg.topic} from MQTT: {msg.payload}")

        # Store data in InfluxDB
        timestamp_ns = int(time.time() * 1e9)  # Convert seconds to nanoseconds
        var_name = msg.topic.split("/")[-1]
        point = Point(var_name).field("value", float(msg.payload.split(b":")[1])).time(timestamp_ns, WritePrecision.NS)
        self.write_api.write(bucket=self.influx_bucket, record=point)

        # Set the value attribute
        self.value_from_message = float(msg.payload.split(b":")[1])

    def run(self):
        # ... (your existing setup code)

        # MQTT Client setup
        mqtt_client = mqtt.Client()
        mqtt_client.on_message = self.on_message
        mqtt_client.connect("192.168.10.248", 1883, 60)

        # Subscribe to the topics in MQTT
        for var_name in ["temperature"]:
            mqtt_client.subscribe(f"opcua/{var_name}")

        mqtt_client.loop_start()

        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            # Close connections
            self.client.disconnect()
            mqtt_client.disconnect()
            self.influx_client.close()
