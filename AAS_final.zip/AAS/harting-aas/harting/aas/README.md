"# harting-aas-sdk" 
