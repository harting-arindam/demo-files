# imports

from basyx.aas import model
from pathlib import Path
from typing import Optional

from create_ReferenceElement import create_reference_element

from identifier import create_id,create_semantic_id_irdi,create_semantic_id_iri
from Submodel_Element_Collection import create_Submodel_Element_Collection
from create_property import create_property,create_multilanguageproperty




# ---------------------------------------------Properties---------------------------------------------


# ------------------------------------------------SME--------------------------------------------------
def create_operatingconditionsoffunctionalsafetycharacteristics_sme():
    return create_Submodel_Element_Collection(name='OperatingConditionsOfFunctionalSafetyCharacteristics',
                                            semanticID=create_semantic_id_iri(value=' 0112/2///62683#ACG057#001',local=False),
                                            value=create_property(
                                                    name_value={'TypeOfVoltage': '','RatedVoltage':'','MinimumRatedVoltage':'','MaximumRatedVoltage':'',
                                                                'RatedOperationalCurrent':'','TypeOfInterlockingDevice':'','OtherOperatingConditions':'','UsefulLifeInNumberOfOperations':'',
                                                                'UsefulLifeInTimeInterval':''},
                                                    semantic_id_type='IRDI',
                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
                                        )
def create_SafetyDeviceTypes_sme():
    return create_Submodel_Element_Collection(name='SafetyDeviceTypes',
                                            semanticID=create_semantic_id_iri(value='0112/2///62683#ACE071#001',local=False),
                                            value=create_property(
                                                    name_value={'FunctionalSafetyDeviceType': ''},
                                                    semantic_id_type='IRDI',
                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                    [
                                                        create_Submodel_Element_Collection(name='SafetyDeviceTypes',
                                                            semanticID=create_semantic_id_iri(value='0112/2///62683#ACG065#00',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                            value=create_property(
                                                                    name_value={'SIL': '','PFH':'','ProofTestInterval':'','PL':'','Category':''},
                                                                    semantic_id_type='IRDI',
                                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                        ),
                                                        create_Submodel_Element_Collection(name='ElectronicElement',
                                                            semanticID=create_semantic_id_iri(value='0112/2///62683#ACG066#001',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                            value=create_property(
                                                                    name_value={'MTTFD': '','RDF':'','ProofTestInterval':''},
                                                                    semantic_id_type='IRDI',
                                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                        ),
                                                        create_Submodel_Element_Collection(name='ElectromechanicalElement',
                                                            semanticID=create_semantic_id_iri(value='0112/2///62683#ACG067#001',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                            value=create_property(
                                                                    name_value={'B10D': '','ProofTestInterval':'',},
                                                                    semantic_id_type='IRDI',
                                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                        ),
                                                        create_Submodel_Element_Collection(name='InherentlySafeSubsystem',
                                                            semanticID=create_semantic_id_iri(value='0112/2///62683#ACG069#001',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                            value=create_property(
                                                                    name_value={'SIL': '','ProofTestInterval':'','PL':'','Category':''},
                                                                    semantic_id_type='IRDI',
                                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
                                                        )
                                                    ]
                                        )


# # ------------------------------------Submodel--------------------------------------------------


# def nameplate_submodel(manufacturer_name:list[str],file_upload:list[str]) -> model.Submodel:
def functionalsafety_submodel() -> model.Submodel:
 
    submodel_creation=model.Submodel(
        id_short='FunctionalSafety',
        identification=create_id('https://admin-shell.io/idta/iec62683/1/0/FunctionalSafety','IRI'),
        category='Submodel',
        semantic_id=create_semantic_id_iri(value='https://admin-shell.io/idta/iec62683/1/0/FunctionalSafety',local=True,key_type=model.KeyElements.SUBMODEL),
        submodel_element=
                    create_property(
                        name_value={'NumberOfFunctionalSafetySetsOfCharacteristics': ''},
                        semantic_id_type='IRDI',
                        semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+

                        [create_operatingconditionsoffunctionalsafetycharacteristics_sme(),
                         create_SafetyDeviceTypes_sme(),
                         ]
                        
                )

    return submodel_creation

