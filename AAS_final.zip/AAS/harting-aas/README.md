# harting-mlops--v.7

This project contains harting-mlops packages
- [Project Structure](#project-structure)
- [Getting Started](#getting-started)
- [Upload Previously created project](#upload-previously-created-project)


## Project Structure
### The repository contains the following directories:


- **datalabelling**: The Python code for labelling/annotating image 

   1. **annotate** : helps in loading Label-studio GUI 
   2. **dload** : help in loading data and establish connection with the S3 bucket
   3. **elabelling** : export the annotated data 
   4. **mlbackend** : to establish connection with ml-backend server suppoted by Label-studio 
   5. **pipeline** : helps to instantiate and load the project using different modules of harting-mlops
   6. **project** : helps to interact with label-studio-client
   7. **uploadprojectfile** : helps to work with the previosly created project in label-studio with the exported zip file and json file


- **training**: The training code that is used to train the model after annotation





## Getting Started
1. Clone the harting-mlops git repository. From the command line, run the following:

    ```bash 
    git clone path/of/the/git/repo
    ```

2. Install setuptools

    ```bash
    pip install setuptools
    ```

3. switch to harting-mlops directory

    ```bash
    cd harting-mlops
    ```

4. build the package

    ```bash
    python setup.py sdist bdist_wheel
    ```
5. install the package

    ```bash
    pip install harting_mlops-0.6-py3-none-any.whl
    ```

To Start the labelling project

NOTE: Before Initializing any project in label studio set the label-studio envirnonment variable

```bash
set LABEL_STUDIO_LOCAL_FILES_SERVING_ENABLED=true
 ```

```bash
set LABEL_STUDIO_LOCAL_FILES_DOCUMENT_ROOT=C:\\path\\to\\AppData
 ```

- [Set-environment-variables](https://labelstud.io/guide/start.html#Set-environment-variables) - Refence for setting the Environment Variable
- [Set-environment-variables](https://labelstud.io/guide/storage#Prerequisites-2 ) - Refence for Pre-requisite






Download **harting-labelling.py** from [pipeline-script](http://192.168.0.100:8005/ai/exploration/-/blob/dev/Arindam/harting-labelling.py)

Replace

    LS_URL = label-studio url
    LS_API_TOKEN = label-studio API token
    ENDPOINT = Endpoint of the Minio-S3 bucket/S3 bucket  (without the http://)
    ACCESS_KEY = Access-key of the S3 bucket
    SECRET_KEY = Secret-key of the S3 bucket


```bash
 python harting-labelling.py --start="NAME-OF-PROJECT" --data path/to/local/directory
```

This will start the label-studio on localhost:8080. with project and data loaded

## Upload Previously created project

harting-datalabelling package also include the package for uploading and working with previously created project.

### Requirements:
#### If labelled dat is in yolo-format

```
    . project-<id>-<datetime>.zip
        ├── images*
        ├── labels
        ├── classes.txt
        └── notes.json 

    . project-<id>-<datetime>.json
```

#### In case json file is not present convert the yolo to json
```    label-studio-converter import yolo -i /yolo/root/directory -o ls-tasks.json```

####  Getteing started with Project

import and load the harting-uploadprojectfile

```bash
from harting.datalabelling.uploadprojectfile import load_project
load_project(<path/of/zip>,<path/of/json>,'Proejct-Name',<id-of-project-mentioned-in-json>)

```

Start the labeling process.



## Training and Fine-Tuning
    NOTE: Model training and finetune(sweep-rehersal) added



