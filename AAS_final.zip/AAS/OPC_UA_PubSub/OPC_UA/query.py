# from influxdb_client import InfluxDBClient

# # Set your InfluxDB connection parameters
# url = "http://localhost:8086"  # Update with your InfluxDB URL
# token = "7jQK7A0Vpgr_iUVu5f0BLX0DRxT3oO3J-b0s2HTNWI6Fw4q5wrnd6DGQDay6dDwyBUXv4XaIxgmxZwKAFpQA1w=="
# org = "harting"
# bucket = "sensordata"

# # Create an InfluxDB client
# client = InfluxDBClient(url=url, token=token, org=org)

# # Create a Flux query
# query = f'from(bucket: "{bucket}") |> range(start: -1h)'

# # Create a synchronous query API
# query_api = client.query_api()

# # Execute the Flux query
# result = query_api.query(query, org=org)

# # Print the query result
# for table in result:
#     for record in table.records:
#         # Print all available fields in the record
#         timestamp = record.values['_time']
#         fields = record.values.keys()
#         print(f"Time: {timestamp}, Fields: {fields}")

# # Close the InfluxDB client
# client.close()



from influxdb_client import InfluxDBClient

# Set your InfluxDB connection parameters
url = "http://localhost:8086"  # Update with your InfluxDB URL
org = "harting"
token = "7jQK7A0Vpgr_iUVu5f0BLX0DRxT3oO3J-b0s2HTNWI6Fw4q5wrnd6DGQDay6dDwyBUXv4XaIxgmxZwKAFpQA1w=="
bucket = "sensordata"

# Create an InfluxDB client
client = InfluxDBClient(url=url, token=token, org=org)

# Create a Flux query
query = f'from(bucket: "{bucket}") |> range(start: -1h)'

# Create a synchronous query API
query_api = client.query_api()

# Execute the Flux query
result = query_api.query(query, org=org)

# Print the query result
for table in result:
    for record in table.records:
        if record.values['_measurement'] == 'temperature':
            timestamp = record.values['_time']
            value = record.values['_value']
            # measurement = record.values['_measurement']
            print(f"Time: {timestamp}, measurement: 'Temp', Value: {value}")

# Close the InfluxDB client
client.close()

