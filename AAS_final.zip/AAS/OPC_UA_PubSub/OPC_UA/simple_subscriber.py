import paho.mqtt.client as mqtt

# Callback when the client receives a CONNACK response from the server
def on_connect(client, userdata, flags, rc):
    print("Connected with result code " + str(rc))

    # Subscribe to the desired topic
    client.subscribe("opcua/temperature")

# Callback when a message is received from the subscribed topic
def on_message(client, userdata, msg):
    print(f"Received message on topic {msg.topic}: {msg.payload.decode()}")

# Create an MQTT client instance
client = mqtt.Client()

# Set the callbacks
client.on_connect = on_connect
client.on_message = on_message

# Connect to the MQTT broker (replace 'broker_address' with your MQTT broker's address)
client.connect("localhost", 1883, 60)

# Start the MQTT client loop
client.loop_start()

# Keep the script running to receive messages
try:
    while True:
        pass
except KeyboardInterrupt:
    # Disconnect the client when the script is interrupted
    client.disconnect()
    print("Disconnected from the MQTT broker.")
