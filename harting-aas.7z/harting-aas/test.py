import paho.mqtt.client as mqtt
from opcua import Client

# Define the OPC UA server address
server_address = "opc.tcp://localhost:4840"

# Create an OPC UA client
client = Client(server_address)

# Connect to the OPC UA server
client.connect()

# Get the root node of the OPC UA server
root_node = client.get_root_node()

# Find the node that represents the temperature sensor
temperature_sensor_node = root_node.get_child("ns=2;i=1001")

# Create an MQTT client
mqtt_client = mqtt.Client()

# Connect to the MQTT broker
mqtt_client.connect("192.168.0.100", 1883)

# Subscribe to the topic that the OPC UA server will publish to
mqtt_client.subscribe("opc_ua/temperature")

# Define a callback function that will be called when a message is received on the subscribed topic
def on_message(client, userdata, msg):
    # Get the temperature value from the message
    temperature = float(msg.payload.decode())

    # Print the temperature value
    print("Temperature:", temperature)

# Start the MQTT client loop
mqtt_client.loop_forever()

# Disconnect from the MQTT broker
mqtt_client.disconnect()

# Disconnect from the OPC UA server
client.disconnect()