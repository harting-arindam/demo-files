import paho.mqtt.client as mqtt

# Define the callback function for when a message is received
def on_message(client, userdata, msg):
  print(msg.topic + ": " + msg.payload)

# Create the MQTT client
client = mqtt.Client()

# Connect to the MQTT broker
client.connect("192.168.0.100", 1883)

# Subscribe to the topic "test/topic"
client.subscribe("test/topic")

# Start the loop to receive messages
client.loop_forever()