# Conatins all the properties and Submodel Collecton for Digital Nameplate

# imports
from basyx.aas import model
from pathlib import Path
from typing import Optional

from create_ReferenceElement import create_reference_element

from identifier import create_id,create_semantic_id_irdi,create_semantic_id_iri
from Submodel_Element_Collection import create_Submodel_Element_Collection
from create_property import create_property,create_multilanguageproperty



# ---------------------------------------------Properties---------------------------------------------


# ------------------------------------------------SME--------------------------------------------------


def create_contactinformation_sme():
    return create_Submodel_Element_Collection(name='ContactInformation',
                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/zvei/nameplate/1/0/ContactInformations/ContactInformation',local=False),
                                            value=
                                                create_property(
                                                    name_value={'RoleOfContactPerson': '', 'Language': '', 'TimeZone':'','AddressOfAdditionalLink':''},
                                                    semantic_id_type='IRDI',
                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+

                                                create_multilanguageproperty(
                                                    name_value={'NationalCode':'','CityTown':'','Company':'','Department':'',
                                                                'Street':'','Zipcode':'','POBox':'','ZipCodeOfPOBox':'',
                                                                'StateCounty':'','NameOfContact':'','FirstName':'','MiddleNames':'',
                                                                'Title':'','AcademicTitle':'','FurtherDetailsOfContact':'','':''},
                                                    semantic_id_type='IRDI',
                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION) +

                                                [create_Submodel_Element_Collection(
                                                    name='Phone',
                                                    semanticID=create_semantic_id_iri(value='https://admin-shell.io/zvei/nameplate/1/0/ContactInformations/ContactInformation/Phone',local=False),
                                                    value=
                                                        create_property(
                                                            name_value={'TypeOfTelephone': ''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                        create_multilanguageproperty(
                                                            name_value={'TelephoneNumber':'','AvailableTime':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)                               
                                                    
                                                    ),
                                                create_Submodel_Element_Collection(
                                                    name='Fax',
                                                    semanticID=create_semantic_id_iri(value='0173-1#02-AAQ834#005',local=False),
                                                    value=
                                                        create_property(
                                                            name_value={'TypeOfFaxNumber': ''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                        create_multilanguageproperty(
                                                            name_value={'FaxNumber':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)      
                                                    ),               
                                                create_Submodel_Element_Collection(
                                                    name='Email',
                                                    semanticID=create_semantic_id_iri(value='0173-1#02-AAQ836#005',local=False),
                                                    value=
                                                        create_property(
                                                            name_value={'EmailAddress': '','TypeOfEmailAddress':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                        create_multilanguageproperty(
                                                            name_value={'PublicKey':'','TypeOfPublicKey':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)    
                                                    ),                           
                                                create_Submodel_Element_Collection(
                                                    name='IPCommunication',
                                                    semanticID=create_semantic_id_iri(value='https://admin-shell.io/zvei/nameplate/1/0/ContactInformations/',local=False),
                                                    value=
                                                        create_property(
                                                            name_value={'AddressOfAdditionalLink': '','TypeOfCommunication':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                        create_multilanguageproperty(
                                                            name_value={'AvailableTime':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)    
                                                    ),                           
                                                    
                                                    ]
                                                )


 
def create_markings_sme():
    return create_Submodel_Element_Collection(name='Markings',
                                            semanticID=create_semantic_id_irdi(value='0173-1#01-AGZ673#001',local=False),
                                            value=
                                            [create_Submodel_Element_Collection(
                                                    name='Marking',
                                                    semanticID=create_semantic_id_irdi(value='0173-1#01-AHD206#001',local=False),
                                                    value=
                                                        create_property(
                                                            name_value={'MarkingName': '','DesignationOfCertificateOrApproval':'','IssueDate': '','ExpiryDate':'','MarkingAdditionalText':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION) +
                                                        [model.File(
                                                            id_short="MarkingFile",
                                                            semantic_id=create_semantic_id_iri(value='https://admin-shell.io/zvei/nameplate/2/0/Nameplate/Markings/Marking/MarkingFile',local=False),
                                                            mime_type="application/pdf",
                                                            value='')] +
                                                        [create_Submodel_Element_Collection(
                                                            name='ExplosionSafeties',
                                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/zvei/nameplate/2/0/Nameplate/Markings/Marking/ExplosionSafeties',local=False),
                                                            value=
                                                               [create_Submodel_Element_Collection(
                                                                    name='ExplosionSafety',
                                                                    semanticID=create_semantic_id_iri(value='https://admin-shell.io/zvei/nameplate/2/0/Nameplate/Markings/Marking/ExplosionSafeties/ExplosionSafety',local=False),
                                                                    value=
                                                                        create_property(
                                                                            name_value={'DesignationOfCertificateOrApproval': '','TypeOfProtection':'','RatedInsulationVoltage': '','SpecificConditionsForUse':'','IncompleteDevice':''},
                                                                            semantic_id_type='IRDI',
                                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION) +
                                                                        create_multilanguageproperty(
                                                                            name_value={'TypeOfApproval':'','ApprovalAgencyTestingAgency':''},
                                                                            semantic_id_type='IRDI',
                                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION) +
                                                                        [create_reference_element(
                                                                            name='InstructionsControlDrawing',
                                                                            semantic_id=create_semantic_id_irdi(value='0112/2///61987#ABO102#001',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                                            ),]+
                                                                        [create_Submodel_Element_Collection(
                                                                            name='AmbientConditions',
                                                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/zvei/nameplate/2/0/Nameplate/Markings/Marking/ExplosionSafeties/ExplosionSafety/AmbientConditions',local=False),
                                                                            value=
                                                                                create_property(
                                                                                    name_value={'DeviceCategory': '','RegionalSpecificMarking':'','TypeOfProtection': '','ExplosionGroup':'',
                                                                                                'MinimumAmbientTemperature':'','MaxAmbientTemperature':'','MaxSurfaceTemperatureForDustProof':'','TemperatureClass':''},
                                                                                    semantic_id_type='IRDI',
                                                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION) +
                                                                                create_multilanguageproperty(
                                                                                    name_value={'EquipmentProtectionLevel':''},
                                                                                    semantic_id_type='IRDI',
                                                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
                                                                                    ),
                                                                         create_Submodel_Element_Collection(
                                                                            name='ProcessConditions',
                                                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/zvei/nameplate/2/0/Nameplate/Markings/Marking/ExplosionSafeties/ExplosionSafety/AmbientConditions',local=False),
                                                                            value=
                                                                                create_property(
                                                                                    name_value={'DeviceCategory': '','RegionalSpecificMarking':'','TypeOfProtection': '','ExplosionGroup':'',
                                                                                                'LowerLimitingValueOfProcessTemperature':'','UpperLimitingValueOfProcessTemperature':'','MaxSurfaceTemperatureForDustProof':'','TemperatureClass':''},
                                                                                    semantic_id_type='IRDI',
                                                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION) +
                                                                                create_multilanguageproperty(
                                                                                    name_value={'EquipmentProtectionLevel':''},
                                                                                    semantic_id_type='IRDI',
                                                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
                                                                                    ),
                                                                         create_Submodel_Element_Collection(
                                                                            name='ExternalElectricalCircuit',
                                                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/zvei/nameplate/2/0/Nameplate/Markings/Marking/ExplosionSafeties/ExplosionSafety/AmbientConditions',local=False),
                                                                            value=
                                                                                create_property(
                                                                                    name_value={'DesignationOfElectricalTerminal': '','TypeOfProtection':'','EquipmentProtectionLevel': '','ExplosionGroup':'',
                                                                                                'Characteristics':'','Fisco':'','TwoWISE':''},
                                                                                    semantic_id_type='IRDI',
                                                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                                                [create_Submodel_Element_Collection(
                                                                                    name='SafetyRelatedPropertiesForPassiveBehaviour',
                                                                                    semanticID=create_semantic_id_irdi(value='0173-1#02-AAQ380#006',local=False),
                                                                                    value=
                                                                                        create_property(
                                                                                            name_value={'MaxInputPower': '','MaxInputVoltage':'','MaxInputCurrent': '','MaxInternalCapacitance':'',
                                                                                                        'MaxInternalInductance':''},
                                                                                            semantic_id_type='IRDI',
                                                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)),
                                                                                create_Submodel_Element_Collection(
                                                                                    name='SafetyRelatedPropertiesForActiveBehaviour',
                                                                                    semanticID=create_semantic_id_irdi(value='0173-1#02-AAQ381#006',local=False),
                                                                                    value=
                                                                                        create_property(
                                                                                            name_value={'MaxOutputPower': '','MaxOutputVoltage':'','MaxOutputCurrent': '','MaxExternalCapacitance':'',
                                                                                                        'MaxExternalInductance':'','MaxExternalInductanceResistanceRatio':''},
                                                                                            semantic_id_type='IRDI',
                                                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION))]

                                                                                
                                                                                
                                                                         
                                                                                    ),
                                                                        ]                           


                                                                        )]
                                                                        
                                                                    )
                                                                ]
                                                    )]   
                                            )
    

def create_assetspecificproperties_sme():
    return create_Submodel_Element_Collection(name='AssetSpecificProperties',
                                            semanticID=create_semantic_id_irdi(value='0173-1#01-AGZ673#001',local=False),
                                            value=
                                            [create_Submodel_Element_Collection(
                                                    name='GuidelineSpecificProperties',
                                                    semanticID=create_semantic_id_irdi(value='0173-1#01-AHD206#001',local=False),
                                                    value=
                                                        create_property(
                                                            name_value={'GuidelineForConformityDeclaration': '','arbitrary':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
                                            )]+
                                            create_property(
                                                            name_value={'arbitory': ''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
                                            )

                                                            
                                       

# # ------------------------------------Submodel--------------------------------------------------


# def nameplate_submodel(manufacturer_name:list[str],file_upload:list[str]) -> model.Submodel:
def nameplate_submodel() -> model.Submodel:
 
    submodel_creation=model.Submodel(
        id_short='Nameplate',
        identification=create_id('https://admin-shell.io/zvei/nameplate/2/0/Nameplate','IRI'),
        category='Submodel',
        semantic_id=create_semantic_id_irdi(value='0173-1#01-AHF578#001',local=True,key_type=model.KeyElements.SUBMODEL),
        submodel_element=
                        create_property(
                                    name_value={'URIOfTheProduct': "2", "SerialNumber": 'ABX-123', "YearOfConstruction": "2023",
                                                "DateOfManufacture":"16/02",'CountryOfOrigin':''},
                                    semantic_id_type='IRDI',
                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                        create_multilanguageproperty(
                                    name_value={'ManufacturerName':'','ManufacturerProductDesignation':'','ManufacturerProductRoot':'',
                                                'ManufacturerProductFamily':'','ManufacturerProductType':'','OrderCodeOfManufacturer':'',
                                                'ProductArticleNumberOfManufacturer':'','HardwareVersion':'','FirmwareVersion':'','SoftwareVersion':''},
                                    semantic_id_type='IRDI',
                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                        [model.File(id_short="CompanyLogo",
                                                mime_type="application/pdf",
                                                value='')]+
                        [create_contactinformation_sme(),
                         create_markings_sme(),
                         create_assetspecificproperties_sme()]
                        
                                    
                        
                        
                )

    return submodel_creation

