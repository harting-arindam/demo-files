import os
from basyx.aas import model
from basyx.aas import adapter
from basyx.aas.adapter import aasx
from pathlib import Path
from submodel_declaration import HandoverDocumentation_submodel


def create_handover_documnetation(document_names:list[str],filepath:list[str]):
    file_store = aasx.DictSupplementaryFileContainer()
    obj_store: model.DictObjectStore[model.Identifiable] = model.DictObjectStore()

    for i,j in zip(filepath,document_names):
        _file = []
        _document_name = []
        with open(Path(i), 'rb') as f:
            file = file_store.add_file(f"/aasx/files/{os.path.basename(i)}", f, "application/pdf")
            _file.append(file)
        _document_name.append(j)

    return [HandoverDocumentation_submodel(document_names=document_names,file_upload=_document_name),file_store]

