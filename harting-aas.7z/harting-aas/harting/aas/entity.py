from basyx.aas import model  


def create_entity(Name:str,entity_type:str):
    if entity_type=='CO_MANAGED_ENTITY':
        entity = model.Entity(
                id_short=Name,
                entity_type=model.EntityType.CO_MANAGED_ENTITY,
                # statement={submodel_element_property, submodel_element_property2},
                statement={},
                asset=None,
                category=None,
                description={'en-us': 'Legally valid designation of the natural or judicial person which is directly '
                                    'responsible for the design, production, packaging and labeling of a product in '
                                    'respect to its being brought into circulation.',
                            'de': 'Bezeichnung für eine natürliche oder juristische Person, die für die Auslegung, '
                                'Herstellung und Verpackung sowie die Etikettierung eines Produkts im Hinblick auf das '
                                '\'Inverkehrbringen\' im eigenen Namen verantwortlich ist'},
                parent=None,
                semantic_id=model.Reference((model.Key(type_=model.KeyElements.GLOBAL_REFERENCE,
                                                    local=False,
                                                    value='http://opcfoundation.org/UA/DI/1.1/DeviceType/Serialnumber',
                                                    id_type=model.KeyType.IRI),)),
                qualifier=None,
                kind=model.ModelingKind.INSTANCE
            )
    elif entity_type=='SELF_MANAGED_ENTITY':
        entity = model.Entity(
                id_short=Name,
                entity_type=model.EntityType.CO_MANAGED_ENTITY,
                # statement={submodel_element_property, submodel_element_property2},
                statement={},
                asset=None,
                category=None,
                description={'en-us': 'Legally valid designation of the natural or judicial person which is directly '
                                    'responsible for the design, production, packaging and labeling of a product in '
                                    'respect to its being brought into circulation.',
                            'de': 'Bezeichnung für eine natürliche oder juristische Person, die für die Auslegung, '
                                'Herstellung und Verpackung sowie die Etikettierung eines Produkts im Hinblick auf das '
                                '\'Inverkehrbringen\' im eigenen Namen verantwortlich ist'},
                parent=None,
                semantic_id=model.Reference((model.Key(type_=model.KeyElements.GLOBAL_REFERENCE,
                                                    local=False,
                                                    value='http://opcfoundation.org/UA/DI/1.1/DeviceType/Serialnumber',
                                                    id_type=model.KeyType.IRI),)),
                qualifier=None,
                kind=model.ModelingKind.INSTANCE
            )
        return entity