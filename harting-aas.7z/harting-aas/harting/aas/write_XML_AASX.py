import basyx.aas.adapter.json
import basyx.aas.adapter.xml
from basyx.aas.adapter import aasx
from basyx.aas import model


def write_xml_to_aasx(xml_filename:str,aasx_file:str):

    with open(xml_filename, 'rb') as xml_file:
        xml_file_data = basyx.aas.adapter.xml.read_aas_xml_file(xml_file)


    file_store = aasx.DictSupplementaryFileContainer()
    with aasx.AASXWriter(aasx_file) as writer:
        writer.write_aas(aas_id=model.Identifier('https://acplt.org/Simple_AAS/handoverdoc',model.IdentifierType.IRI),
                        object_store=xml_file_data,
                        file_store=file_store,
                        submodel_split_parts=False)
    return aasx_file+" "+"created"

