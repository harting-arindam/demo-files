# function to create different identifier Attribute
from typing import Optional,Union
from pathlib import Path
from basyx.aas import model
from utils import serial_no


def create_id(id:Union[str,Path],id_type:str) -> model.Identifier:
    """
    Creates an unique Identifier of different Identifiable like Asset
    AdministrationShell
    Asset
    Submodel
    ConceptDescription

    id_type = IRI,IRDI,CUSTOM

    :return: example submodel
    """

    if id_type == "IRI":
        identifier = model.Identifier(id_= id,
                                    id_type=model.IdentifierType.IRI)
    elif id_type == "IRDI":
        identifier = model.Identifier(id_= id,
                                    id_type=model.IdentifierType.IRDI)
    else:
        identifier = model.Identifier(id = id,
                                    id_type = model.IdentifierType.CUSTOM)

    return identifier

def create_id_short(Name : str):
    return str(Name)


def create_semantic_id_iri(
    value: str = "",
    local:bool = True,
    id_type:model.KeyType = model.KeyType.IRI,
    key_type: model.KeyElements = model.KeyElements.GLOBAL_REFERENCE,
    lang:Optional[str]=None
) -> model.Reference:
    return model.Reference((model.Key(key_type,local,value,id_type),))


def create_semantic_id_irdi(
    value: str = "",
    local:bool = True,
    id_type:model.KeyType = model.KeyType.IRDI,
    key_type: model.KeyElements = model.KeyElements.GLOBAL_REFERENCE,
    lang:Optional[str]=None
) -> model.Reference:
    return model.Reference((model.Key(key_type,local,value,id_type),))

def create_semantic_id_custom(
    value: str = "",
    local:bool = True,
    id_type:model.KeyType = model.KeyType.CUSTOM,
    key_type: model.KeyElements = model.KeyElements.GLOBAL_REFERENCE,
) -> model.Reference:
    return model.Reference((model.Key(key_type,local,value,id_type),))