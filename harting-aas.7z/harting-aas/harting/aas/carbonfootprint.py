# imports

from basyx.aas import model
from pathlib import Path
from typing import Optional

from create_ReferenceElement import create_reference_element

from identifier import create_id,create_semantic_id_irdi,create_semantic_id_iri
from Submodel_Element_Collection import create_Submodel_Element_Collection
from create_property import create_property,create_multilanguageproperty




# ---------------------------------------------Properties---------------------------------------------


# ------------------------------------------------SME--------------------------------------------------
def create_productcarbonfootprint_sme():
    return create_Submodel_Element_Collection(name='ProductCarbonFootprint',
                                            semanticID=create_semantic_id_irdi(value='0173-1#01-AHE716#001',local=False),
                                            value=
                                                create_property(
                                                    name_value={'PCFCalculationMethod': '', 'PCFCO2eq': '', 'PCFReferenceValueForCalculation':'','PCFQuantityOfMeasureForCalculation':'','PCFLiveCyclePhase':''},
                                                    semantic_id_type='IRDI',
                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                            [   model.File(
                                                    id_short="ExplanatoryStatement",
                                                    semantic_id=create_semantic_id_iri(value='https://example.com/ids/cd/3291_7022_2032_0718',local=False),
                                                    mime_type="application/pdf",
                                                    # value=filepath,
                                                ),
                                            ]+
                                            [
                                                create_Submodel_Element_Collection(
                                                    name='PCFGoodsAddressHandover',
                                                    semanticID=create_semantic_id_irdi(value='0173-1#02-ABI497#001',local=False),
                                                    value=create_property(
                                                            name_value={'Street': '', 'HouseNumber': '', 'ZipCode':'','CityTown':'','Country':'','Latitude':'','Longitude':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION
                                                            )
                                                )
                                            ]                                  
                                            
                                            )

def create_transportcarbonfootprint_sme():
    return create_Submodel_Element_Collection(name='TransportCarbonFootprint',
                                            semanticID=create_semantic_id_irdi(value='0173-1#01-AHE717#001',local=False),
                                            value=
                                                create_property(
                                                    name_value={'TCFCalculationMethod': '', 'TCFCO2eq': '', 'TCFReferenceValueForCalculation':'','TCFQuantityOfMeasureForCalculation':'','TCFProcessesForGreenhouseGasEmissionInATransportService':''},
                                                    semantic_id_type='IRDI',
                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                            [   model.File(
                                                    id_short="ExplanatoryStatement",
                                                    semantic_id=create_semantic_id_iri(value='https://example.com/ids/cd/3291_7022_2032_0718',local=False),
                                                    mime_type="application/pdf",
                                                    # value=filepath,
                                                ),
                                            ]+
                                            [
                                                create_Submodel_Element_Collection(
                                                    name='TCFGoodsTransportAddressTakeover',
                                                    semanticID=create_semantic_id_irdi(value='0173-1#02-ABI497#001',local=False),
                                                    value=create_property(
                                                            name_value={'Street': '', 'HouseNumber': '', 'ZipCode':'','CityTown':'','Country':'','Latitude':'','Longitude':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION
                                                            )
                                                ),
                                                create_Submodel_Element_Collection(
                                                    name='TCFGoodsTransportAddressHandover',
                                                    semanticID=create_semantic_id_irdi(value='0173-1#02-ABI498#001',local=False),
                                                    value=create_property(
                                                            name_value={'Street': '', 'HouseNumber': '', 'ZipCode':'','CityTown':'','Country':'','Latitude':'','Longitude':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION
                                                            )
                                                )
                                            ]                                  
                                            
                                            )





# # ------------------------------------Submodel--------------------------------------------------


# def nameplate_submodel(manufacturer_name:list[str],file_upload:list[str]) -> model.Submodel:
def carbonfootprint_submodel() -> model.Submodel:
 
    submodel_creation=model.Submodel(
        id_short='CarbonFootprint',
        identification=create_id('0173-1#01-AHE712#001','IRDI'),
        category='Submodel',
        semantic_id=create_semantic_id_irdi(value='0173-1#01-AHE712#001',local=True,key_type=model.KeyElements.SUBMODEL),
        submodel_element=
                        [create_productcarbonfootprint_sme(),
                         create_transportcarbonfootprint_sme()]
                        
                )

    return submodel_creation

