# imports

from basyx.aas import model
from pathlib import Path
from typing import Optional

from create_ReferenceElement import create_reference_element

from identifier import create_id,create_semantic_id_irdi,create_semantic_id_iri
from Submodel_Element_Collection import create_Submodel_Element_Collection
from create_property import create_property,create_multilanguageproperty




# ---------------------------------------------Properties---------------------------------------------


# ------------------------------------------------SME--------------------------------------------------
def create_interfaces_sme():
    return create_Submodel_Element_Collection(name='Interfaces',
                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/ControlComponent/Type/Interfaces/1/0',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                            value=
                                            [create_reference_element(
                                                        name='Interface',
                                                        semantic_id=create_semantic_id_iri(value='https://admin-shell.io/idta/ControlComponent/Type/Interface/1/0',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                        )]                   
                        
                                            )

def create_skills_sme():
    return create_Submodel_Element_Collection(name='Skills',
                                            semanticID=create_semantic_id_irdi(value='0173-1#01-AHE717#001',local=False),
                                            value=
                                            [
                                                create_Submodel_Element_Collection(
                                                    name='Skill',
                                                    semanticID=create_semantic_id_irdi(value='https://admin-shell.io/idta/ControlComponent/Skill/1/0',local=True),
                                                    value=create_property(
                                                            name_value={'Name': '', 'Disabled': '',},
                                                            semantic_id_type='IRI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION
                                                            )+
                                                            create_multilanguageproperty(
                                                            name_value={'DisplayName':''},
                                                            semantic_id_type='IRI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION) +

                                                            [
                                                                create_Submodel_Element_Collection(
                                                                    name='Modes',
                                                                    semanticID=create_semantic_id_iri(value=' https://admin-shell.io/idta/ControlComponent/Skill/Modes/1/0',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                                    value=create_property(
                                                                            name_value={'Mode': ''},
                                                                            semantic_id_type='IRI',
                                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION
                                                                            )
                                                                        ),
                                                                create_Submodel_Element_Collection(
                                                                    name='Parameter',
                                                                    semanticID=create_semantic_id_irdi(value='https://admin-shell.io/idta/ControlComponent/Skill/Parameters/1/0',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                                    value=
                                                                    [
                                                                        create_Submodel_Element_Collection(
                                                                            name='Parameter',
                                                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/ControlComponent/Skill/Parameter/1/0',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                                            value=create_property(
                                                                                    name_value={'Name': '','Direction':'','Type':''},
                                                                                    semantic_id_type='IRI',
                                                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION
                                                                                    )+
                                                                                    [
                                                                                        create_Submodel_Element_Collection(
                                                                                            name='Values',
                                                                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/ControlComponent/Skill/Parameter/Values/1/0',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                                                        )
                                                                                    ]
                                                                        )
                                                                    ]
                                                                        ),
                                                                create_Submodel_Element_Collection(
                                                                    name='Errors',
                                                                    semanticID=create_semantic_id_irdi(value='https://admin-shell.io/idta/ControlComponent/Skill/Errors/1/0',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                                    
                                                                        ),
                                                                create_Submodel_Element_Collection(
                                                                    name='Uses',
                                                                    semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/ControlComponent/Skill/Uses/1/0',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                                                   
                                                                        ),
                                                            ]
                                                ),
                                                
                                            ]                                  
                                            
                                            )
def create_errors_sme():
    return create_Submodel_Element_Collection(name='Errors',
                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/idta/ControlComponent/Type/Errors/1/0',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                                            value=
                                                create_multilanguageproperty(
                                                    name_value={'ErrorCode':''},
                                                    semantic_id_type='IRI',
                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)             
                        
                                            )





# # ------------------------------------Submodel--------------------------------------------------


# def nameplate_submodel(manufacturer_name:list[str],file_upload:list[str]) -> model.Submodel:
def controlcomponenttype_submodel() -> model.Submodel:
 
    submodel_creation=model.Submodel(
        id_short='ControlComponentType',
        identification=create_id('https://example.com/ids/sm/5213_1120_8022_9305/1','IRI'), # check the identifier
        category='Submodel',
        semantic_id=create_semantic_id_irdi(value=' https://admin-shell.io/idta/ControlComponent/Type/1/0',local=False,key_type=model.KeyElements.SUBMODEL),
        submodel_element=
                        [create_interfaces_sme(),
                         create_skills_sme(),
                         create_errors_sme()]
                        
                )

    return submodel_creation

