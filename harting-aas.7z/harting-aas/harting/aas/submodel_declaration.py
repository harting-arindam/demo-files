# creating a empty submodel
from basyx.aas import model
from create_property import create_property,create_multilanguageproperty
from identifier import create_id,create_semantic_id_iri,create_semantic_id_irdi
from Submodel_Element_Collection import create_Submodel_Element_Collection
from Submodel_Element_Collection import create_documentid_sme,create_documentclassification_sme,create_documentversion_sme
# from Submodel_Element_Collection import create_documentid_sme,create_documentclassification_sme


from pathlib import Path
from entity import create_entity
from qualifier import qualifier_cardinality,qualifier_ExampleValue,qualifier_KeyValue

def create_empty_submodel(submodel_name: str) -> model.Submodel:
    return model.Submodel(
        id_short=submodel_name,
        identification=model.Identifier(id_='https://acplt.org/Test_Submodel2_Mandatory',
                                        id_type=model.IdentifierType.IRI))


# ------------------------------------for HandoverDocumentation--------------------------------------------------

def HandoverDocumentation_submodel(document_names:list[str],file_upload:list[str]) -> model.Submodel:


    submodel_property = create_property(name_value={'numberOfDocuments':str(len(document_names))},semantic_id_type='IRDI',semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
    submodel_entity = model.Entity(
        id_short='Entity',
        entity_type=model.EntityType.CO_MANAGED_ENTITY,
        statement=(),
        # asset=None,
        asset=model.AASReference((model.Key(type_=model.KeyElements.ASSET,
                                            local=False,
                                            value='https://acplt.org/Simple_AAS',
                                            id_type=model.KeyType.IRI),),
                                 model.Asset),
        category=None,
        description=None,
        parent=None,
        semantic_id=create_semantic_id_iri(value='https://admin-shell.io/vdi/2770/1/0/EntityForDocumentation',local=False),
        # qualifier={qualifier_cardinality('ZeroToMany')},
        kind=model.ModelingKind.INSTANCE
    )
    submodel_creation=model.Submodel(
        id_short='Handover_Documentation',
        identification=create_id('https://admin-shell.io/IDTA02004-1-2','IRI'),
        category='Submodel',
        semantic_id=create_semantic_id_irdi(value='0173-1#01-AHF578#001',local=True,key_type=model.KeyElements.SUBMODEL),
        submodel_element=submodel_property,
                    )
    for _names,_files in zip(document_names,file_upload):
        documentid = create_documentid_sme(document_domain_id='Harting Technology groups',value_id=_files,is_primary=True)
        document_classification = create_documentclassification_sme(class_name={'en': 'document'})                                            
        document_version = create_documentversion_sme(
                        title=_names,
                        sub_title=_names+'subtitle',
                        summary='demo-summary',
                        
                        organization_name='HARTING Technology Groups',
                        document_language='en',
                        filepath=_files
                        )
        

        group = model.SubmodelElementCollectionOrdered(
                id_short=_names,
                value={
                    documentid,
                    document_classification,
                    document_version
                    },
                
                semantic_id=create_semantic_id_irdi(value='0173-1#02-ABI500#001/0173-1#01-AHF579#001',local=True,key_type=model.KeyElements.CONCEPT_DESCRIPTION),
                # qualifier={qualifier_cardinality('ZeroToMany')}
                )
        submodel_creation.submodel_element.add(group)
 
    submodel_creation.submodel_element.add(submodel_entity)


    return submodel_creation



