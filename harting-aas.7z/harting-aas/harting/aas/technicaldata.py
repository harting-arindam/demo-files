# imports

from basyx.aas import model
from pathlib import Path
from typing import Optional

from create_ReferenceElement import create_reference_element

from identifier import create_id,create_semantic_id_irdi,create_semantic_id_iri
from Submodel_Element_Collection import create_Submodel_Element_Collection
from create_property import create_property,create_multilanguageproperty




# ---------------------------------------------Properties---------------------------------------------


# ------------------------------------------------SME--------------------------------------------------
def create_generalinformation_sme():
    return create_Submodel_Element_Collection(name='GeneralInformation',
                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/ZVEI/TechnicalData/GeneralInformation/1/1',local=False),
                                            value=
                                                create_property(
                                                    name_value={'ManufacturerName': '', 'ManufacturerArticleNumber': '', 'ManufacturerOrderCode':''},
                                                    semantic_id_type='IRDI',
                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                create_multilanguageproperty(
                                                    name_value={'ManufacturerProductDesignation':''},
                                                    semantic_id_type='IRDI',
                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                            [   model.File(
                                                id_short="ManufacturerLogo",
                                                semantic_id=create_semantic_id_iri(value='https://admin-shell.io/ZVEI/TechnicalData/ManufacturerLogo/1/1',local=False),
                                                mime_type="application/pdf",
                                                # value=filepath,
                                                ),
                                                model.File(
                                                id_short="ProductImage",
                                                semantic_id=create_semantic_id_iri(value='https://admin-shell.io/ZVEI/TechnicalData/ProductImage/1/1',local=False),
                                                mime_type="application/pdf",
                                                # value=filepath,
                                                )]                                  
                                            
                                            )

def create_productclassificationsn_sme():
    return create_Submodel_Element_Collection(name='ProductClassifications',
                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/ZVEI/TechnicalData/ProductClassifications/1/1',local=False),
                                            value=
                                            [create_Submodel_Element_Collection(
                                                    name='ProductClassificationItem',
                                                    semanticID=create_semantic_id_iri(value='https://admin-shell.io/ZVEI/TechnicalData/ProductClassificationItem/1/1',local=False),
                                                    value=
                                                        create_property(
                                                            name_value={'ProductClassificationSystem': '','ClassificationSystemVersion':'','ProductClassId':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
                                            )]
                                        )
def create_technicalproperties_sme():
    return create_Submodel_Element_Collection(name='TechnicalProperties',
                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/ZVEI/TechnicalData/TechnicalProperties/1/1',local=False),
                                            value=
                                            [create_Submodel_Element_Collection(
                                                    name='ProductClassificationItem',
                                                    semanticID=create_semantic_id_iri(value='https://admin-shell.io/ZVEI/TechnicalData/ProductClassificationItem/1/1',local=False),
                                                   
                                            )]
                                        )

def create_furtherinformation_sme():
    return create_Submodel_Element_Collection(name='FurtherInformation',
                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/ZVEI/TechnicalData/FurtherInformation/1/1',local=False),
                                            value=
                                            [create_Submodel_Element_Collection(
                                                    name='ProductClassificationItem',
                                                    semanticID=create_semantic_id_iri(value='https://admin-shell.io/ZVEI/TechnicalData/ProductClassificationItem/1/1',local=False),
                                                    value=
                                                        create_property(
                                                            name_value={'ValidDate': ''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                        create_multilanguageproperty(
                                                            name_value={'TextStatement':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)
                                            )]
                                        )






# # ------------------------------------Submodel--------------------------------------------------


# def nameplate_submodel(manufacturer_name:list[str],file_upload:list[str]) -> model.Submodel:
def technicaldata_submodel() -> model.Submodel:
 
    submodel_creation=model.Submodel(
        id_short='TechnicalData',
        identification=create_id('https://admin-shell.io/ZVEI/TechnicalData/Submodel/1/2','IRI'),
        category='Submodel',
        semantic_id=create_semantic_id_iri(value=' https://admin-shell.io/ZVEI/TechnicalData/Submodel/1/2',local=True,key_type=model.KeyElements.SUBMODEL),
        submodel_element=
                        [create_generalinformation_sme(),
                         create_productclassificationsn_sme(),
                         create_technicalproperties_sme(),
                         create_furtherinformation_sme()]
                        
                                    
                        
                        
                )

    return submodel_creation

