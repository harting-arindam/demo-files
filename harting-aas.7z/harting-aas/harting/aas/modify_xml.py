from lxml import etree

def modify_elements_value(xml_filename:str,type:str,idshort:str,modified_value:str)->dict:

    # Define the namespaces used in the XML file
    namespaces = {
        'aas': 'http://www.admin-shell.io/aas/2/0',
        'abac': 'http://www.admin-shell.io/aas/abac/2/0',
        'aas_common': 'http://www.admin-shell.io/aas_common/2/0',
        'xsi': 'http://www.w3.org/2001/XMLSchema-instance',
        'IEC': 'http://www.admin-shell.io/IEC61360/2/0',
        'xs': 'http://www.w3.org/2001/XMLSchema'
    }

    # Create the root element with namespaces
    root = etree.Element('{http://www.admin-shell.io/aas/2/0}aasenv', nsmap=namespaces)

    # Load the XML file with namespaces
    tree = etree.parse(xml_filename)

    # Find the submodel element with idShort "numberOfDocuments" using namespaces
  
    element_to_update = tree.find(f".//aas:{type}[aas:idShort='{idshort}']", namespaces)

    # Update the value of the "value" element
    value_element = element_to_update.find('.//aas:value', namespaces)
    value_element.text = modified_value

    # Save the modified XML to a new file or overwrite the existing one
    tree.write(xml_filename, xml_declaration=True, encoding='utf-8', method='xml', pretty_print=True)

    return {
        'file-modified':xml_filename,
        'element':type,
        'idshort':idshort,
        'modified_value':modified_value
            }
def modify_elements_attribute(xml_filename:str,type:str,idshort:str,attribute_name:str,modified_attribute_value:str)->dict:

    # Define the namespaces used in the XML file
    namespaces = {
        'aas': 'http://www.admin-shell.io/aas/2/0',
        'abac': 'http://www.admin-shell.io/aas/abac/2/0',
        'aas_common': 'http://www.admin-shell.io/aas_common/2/0',
        'xsi': 'http://www.w3.org/2001/XMLSchema-instance',
        'IEC': 'http://www.admin-shell.io/IEC61360/2/0',
        'xs': 'http://www.w3.org/2001/XMLSchema'
    }

    # Create the root element with namespaces
    root = etree.Element('{http://www.admin-shell.io/aas/2/0}aasenv', nsmap=namespaces)

    # Load the XML file with namespaces
    tree = etree.parse(xml_filename)

    # Find the submodel element with idShort "numberOfDocuments" using namespaces
  
    element_to_update = tree.find(f".//aas:{type}[aas:idShort='{idshort}']", namespaces)

    # Update the attribute
    attribute_to_modify  = element_to_update.find('.//aas:{tag}', namespaces)
    attribute_to_modify.set({attribute_name,modified_attribute_value})


    # Save the modified XML to a new file or overwrite the existing one
    tree.write(xml_filename, xml_declaration=True, encoding='utf-8', method='xml', pretty_print=True)

    return {
        'file-modified':xml_filename,
        'element':type,
        'idshort':idshort,
        'attribute_name':modified_attribute_value
            }