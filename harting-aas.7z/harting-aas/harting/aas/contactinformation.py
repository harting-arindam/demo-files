# imports

from basyx.aas import model
from pathlib import Path
from typing import Optional

from create_ReferenceElement import create_reference_element

from identifier import create_id,create_semantic_id_irdi,create_semantic_id_iri
from Submodel_Element_Collection import create_Submodel_Element_Collection
from create_property import create_property,create_multilanguageproperty




# ---------------------------------------------Properties---------------------------------------------


# ------------------------------------------------SME--------------------------------------------------
def create_contactinformation_sme():
    return create_Submodel_Element_Collection(name='ContactInformation',
                                            semanticID=create_semantic_id_iri(value='https://admin-shell.io/zvei/nameplate/1/0/ContactInformations/ContactInformation',local=False),
                                            value=
                                                create_property(
                                                    name_value={'RoleOfContactPerson': '', 'Language': '', 'TimeZone':'','AddressOfAdditionalLink':''},
                                                    semantic_id_type='IRDI',
                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+

                                                create_multilanguageproperty(
                                                    name_value={'NationalCode':'','CityTown':'','Company':'','Department':'',
                                                                'Street':'','Zipcode':'','POBox':'','ZipCodeOfPOBox':'',
                                                                'StateCounty':'','NameOfContact':'','FirstName':'','MiddleNames':'',
                                                                'Title':'','AcademicTitle':'','FurtherDetailsOfContact':'','':''},
                                                    semantic_id_type='IRDI',
                                                    semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION) +

                                                [create_Submodel_Element_Collection(
                                                    name='Phone',
                                                    semanticID=create_semantic_id_iri(value='https://admin-shell.io/zvei/nameplate/1/0/ContactInformations/ContactInformation/Phone',local=False),
                                                    value=
                                                        create_property(
                                                            name_value={'TypeOfTelephone': ''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                        create_multilanguageproperty(
                                                            name_value={'TelephoneNumber':'','AvailableTime':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)                               
                                                    
                                                    ),
                                                create_Submodel_Element_Collection(
                                                    name='Fax',
                                                    semanticID=create_semantic_id_iri(value='0173-1#02-AAQ834#005',local=False),
                                                    value=
                                                        create_property(
                                                            name_value={'TypeOfFaxNumber': ''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                        create_multilanguageproperty(
                                                            name_value={'FaxNumber':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)      
                                                    ),               
                                                create_Submodel_Element_Collection(
                                                    name='Email',
                                                    semanticID=create_semantic_id_iri(value='0173-1#02-AAQ836#005',local=False),
                                                    value=
                                                        create_property(
                                                            name_value={'EmailAddress': '','TypeOfEmailAddress':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                        create_multilanguageproperty(
                                                            name_value={'PublicKey':'','TypeOfPublicKey':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)    
                                                    ),                           
                                                create_Submodel_Element_Collection(
                                                    name='IPCommunication',
                                                    semanticID=create_semantic_id_iri(value='https://admin-shell.io/zvei/nameplate/1/0/ContactInformations/',local=False),
                                                    value=
                                                        create_property(
                                                            name_value={'AddressOfAdditionalLink': '','TypeOfCommunication':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)+
                                                        create_multilanguageproperty(
                                                            name_value={'AvailableTime':''},
                                                            semantic_id_type='IRDI',
                                                            semantic_id_key_type=model.KeyElements.CONCEPT_DESCRIPTION)    
                                                    ),                           
                                                    
                                                    ]
                                                )



# # ------------------------------------Submodel--------------------------------------------------


# def nameplate_submodel(manufacturer_name:list[str],file_upload:list[str]) -> model.Submodel:
def contactinformation_submodel() -> model.Submodel:
 
    submodel_creation=model.Submodel(
        id_short='ContactInformation',
        identification=create_id(' https://example.com/ids/sm/1231_6162_1022_9579','IRI'),
        category='Submodel',
        semantic_id=create_semantic_id_irdi(value='https://admin-shell.io/zvei/nameplate/1/0/ContactInformations',local=True,key_type=model.KeyElements.SUBMODEL),
        submodel_element=
                        [create_contactinformation_sme()]
                        
                )

    return submodel_creation

