import os
from basyx.aas import model
from basyx.aas import adapter
from basyx.aas.adapter import aasx

from create_property import create_property
from asset import create_asset
from submodel_declaration import HandoverDocumentation_submodel
from nameplate import nameplate_submodel
from technicaldata import technicaldata_submodel
from carbonfootprint import carbonfootprint_submodel
from contactinformation import contactinformation_submodel
from ControlComponentInstance import controlcomponentinstance_submodel
from ControlComponentType import controlcomponenttype_submodel
from dexpi import dexpi_submodel
from functionalSafety import functionalsafety_submodel
from timeseries import timeseries_submodel
from Submodel_Element_Collection import create_Submodel_Element_Collection
from identifier import create_semantic_id_irdi
from pathlib import Path
import basyx.aas.adapter.json
import basyx.aas.adapter.xml

file_store = aasx.DictSupplementaryFileContainer()
obj_store: model.DictObjectStore[model.Identifiable] = model.DictObjectStore()

filepath = ['C:\Data-WithBackup\HARTING-AAS\exploration\data\PDF_DS_09200030801_DE.pdf',
            'C:\Data-WithBackup\HARTING-AAS\exploration\data\PDF_DS_09200030801_EN.pdf',
            'C:\Data-WithBackup\HARTING-AAS\exploration\data\PDF_PD_09200030801_EN.pdf']

_file = []
for i in filepath:
    with open(Path(i), 'rb') as f:
        file = file_store.add_file(f"/aasx/files/{os.path.basename(i)}", f, "application/pdf")
        _file.append(file)
    
# /aasx/files/PDF_DS_09200030801_DE.pdf
asset = create_asset('HARTINGAAS','https://acplt.org/Simple_Asset')

submodel_handoverdocumentation = HandoverDocumentation_submodel(['Datasheet','Typesheet','ProductDeclaration'],_file)
submodel_nameplate = nameplate_submodel()
submodel_technicaldata = technicaldata_submodel()
submodel_carbonfootprint = carbonfootprint_submodel()
submodel_contactinformation = contactinformation_submodel()
submodel_controlcomponentinstance = controlcomponentinstance_submodel()
submodel_controlcomponenttype = controlcomponenttype_submodel()
submodel_dexpi = dexpi_submodel()
submodel_functionalsafety = functionalsafety_submodel()
submodel_timeseries = timeseries_submodel()


aas = model.AssetAdministrationShell(
    identification=model.Identifier('https://acplt.org/Simple_AAS', model.IdentifierType.IRI),
    id_short="HartingHandoverDocDemo_2",
    asset=model.AASReference.from_referable(asset),
    submodel={model.AASReference.from_referable(submodel_handoverdocumentation),
              model.AASReference.from_referable(submodel_nameplate),
              model.AASReference.from_referable(submodel_technicaldata),
              model.AASReference.from_referable(submodel_carbonfootprint),
              model.AASReference.from_referable(submodel_contactinformation),
              model.AASReference.from_referable(submodel_controlcomponentinstance),
              model.AASReference.from_referable(submodel_controlcomponenttype),
              model.AASReference.from_referable(submodel_dexpi),
              model.AASReference.from_referable(submodel_functionalsafety),
              model.AASReference.from_referable(submodel_timeseries)}
)
obj_store.add(asset)
obj_store.add(submodel_handoverdocumentation)
obj_store.add(submodel_nameplate)
obj_store.add(submodel_technicaldata)
obj_store.add(submodel_carbonfootprint)
obj_store.add(submodel_contactinformation)
obj_store.add(submodel_controlcomponentinstance)
obj_store.add(submodel_controlcomponenttype)
obj_store.add(submodel_dexpi)
obj_store.add(submodel_functionalsafety)
obj_store.add(submodel_timeseries)
obj_store.add(aas)

with aasx.AASXWriter(r"C:\Data-WithBackup\HARTING-AAS\harting-aas-sdk\aasx-files\Arindammid1.aasx") as writer:
    writer.write_aas(aas_id=model.Identifier('https://acplt.org/Simple_AAS',model.IdentifierType.IRI),
                     object_store=obj_store,
                     file_store=file_store,
                     submodel_split_parts=False)
    

    

