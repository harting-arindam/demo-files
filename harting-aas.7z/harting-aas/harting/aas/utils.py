import itertools

# serial number
id_iter = itertools.count(start=1, step=1)

def serial_no():    
    s_no = str(next(id_iter)).zfill(2)
    return s_no


    # concept_description = model.ConceptDescription(
    # identification=model.Identifier(id_='https://acplt.org/Test_ConceptDescription',
    #                                 id_type=model.IdentifierType.IRI),
    # is_case_of={model.Reference((model.Key(type_=model.KeyElements.GLOBAL_REFERENCE,
    #                                         local=False,
    #                                         value='http://acplt.org/DataSpecifications/'
    #                                                 'ConceptDescriptions/TestConceptDescription',
    #                                         id_type=model.KeyType.IRI),))},
    # id_short='TestConceptDescription',
    # category=None,
    # description={'en-us': 'An example concept description  for the test application',
    #                 'de': 'Ein Beispiel-ConceptDescription für eine Test-Anwendung'},
    # parent=None,
    # administration=model.AdministrativeInformation(version='0.9',
    #                                                 revision='0'))
