import requests
import base64

def uploadAssxToServer(aasIds:str,aasx_file_path:str):
    '''
    Example:
    AddAsset(aasIds= "https://acplt.org/Simple_AAS",
             aasx_file_path= "path/to/aasx/file")

    '''
    
    # asset_id = "aHR0cHM6Ly9hY3BsdC5vcmcvU2ltcGxlX0FBUy9oYW5kb3ZlcmRvYw"   
    aasIds_base64 = base64.b64encode(bytes(aasIds, 'utf-8'))
   
    repository_url = "http://192.168.0.100:51001/packages"
    aasx_post = repository_url+"?aasIds="+str(aasIds_base64)

    session = requests.Session()
    with open(aasx_file_path, "rb") as file:
        files = {'file': file}
        # response = requests.post(url, files=files)

        response = session.request("POST",aasx_post,files=files)    

    # print(response)
    # print(response.text)
    return print(response.text)
#Asset generated with basyx-python-sdk example
aasx = r"C:\Data-WithBackup\HARTING-AAS\harting-aas\harting\aas\TimeseriesAAS.aasx"

uploadAssxToServer(aasIds= "https://acplt.org/Simple_AAS/timeseries",
                    aasx_file_path= aasx)