from basyx.aas import model
from typing import Optional

def create_range(name:str,semantic_id:model.Reference,min_value:Optional[int]=None,max_value:Optional[int]=None,):
    range_ = model.Range(
        id_short=name,
        value_type=model.datatypes.Int,
        min=min_value,
        max=max_value,
        category='PARAMETER',
        description={'en-us': 'Example Range object',
                     'de': 'Beispiel Range Element'},
        parent=None,
        semantic_id=semantic_id,
        qualifier=None,
        kind=model.ModelingKind.INSTANCE)
    return range_