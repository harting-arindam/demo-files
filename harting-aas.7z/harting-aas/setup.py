import setuptools

with open("requirements.txt", "r", encoding="utf-8") as fh:
    install_requires = fh.readlines()

setuptools.setup(
    name="harting-aas-sdk",
    version="0.1",
    author="Arindam Chakraborty",
    description="aas in Python",
    packages=[
        "harting.aas"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    install_requires=install_requires,
    python_requires=">=3.9",
    setup_requires=["wheel"],
)
